module.exports = {
    es: {
        title: "",
        recentPosts: "Publicaciones reciente",
        tagsCloud: "Etiquetas",
        searchPlaceholder: "Buscar...",
        followUs: "Redes sociales",
        next: "Siguiente",
        prev: "Anterior",
        heroCallout: "Hola, soy Edwin Torres. Escribo sobre mis intereses en",
        heroSupport: "Comienza por las publicaciones más recientes o revisa mi README.",
        typedMessage1: "tecnología.",
        typedMessage2: "tecnología",
        typedMessage3: "tecnología y datos",
        typedMessage4: "tecnología",
        typedMessage5: "tecnología, datos y personas.",
        readme: "README",
        engineer: "Ingeniero",
        photoBy: "Foto por",
        on: "en",
        language: "Idioma",
        readMore: "Lee más",
        morePosts: "Más publicaciones",
        aboutMeIntro: "Hi! Mi nombre es Edwin Torres o Edwin Torres Hernández o Edwin Torres-Hernandez o simplemente Edwin. Soy padre de dos hijos, boricua (puertorriqueño) y esposo de una ministra de la Iglesia Presbiteriana (EE. UU.). Mi lengua materna es el español, pero aprendí inglés cuando tenía veinte años. Mis pronombres son él/he.",
        toc: "Tabla de Contenido"

    }
  };