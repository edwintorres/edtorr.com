module.exports = {
    en: {
        title: "",
        recentPosts: "Recent Posts",
        tagsCloud: "Tags Cloud",
        searchPlaceholder: "Search Keywords...",
        followUs: "Social Media",
        next: "Next",
        prev: "Previous",
        heroCallout: "Hi, I’m Edwin Torres.",
        heroSupport: "I work on solving real-world problems and improve people lives through technology and data.",
        typedMessage1: "",
        typedMessage2: "",
        typedMessage3: "",
        typedMessage4: "",
        typedMessage5: "",
        readme: "README",
        engineer: "Engineer",
        photoBy: "Photo by",
        on: "on",
        language: "Language",
        readMore: "Read More",
        morePosts: "More posts",
        aboutMeIntro: "",
        toc: "Table of Content"
    }
  };